# TinyLink

TinyLink — a minimal URL shortener built for the TinyLink take-home assignment.

## Stack
- Next.js (App Router)
- Node.js
- PostgreSQL (Neon recommended)
- `pg` for DB access
- Deploy: Vercel

## Features
- Create short links (custom code optional)
- List all links
- Redirect `/:code` (302) and update clicks & last_clicked
- Stats page: `/code/:code`
- Delete link
- Health check: `/healthz`

## Install & Run locally
1. Copy `.env.example` → `.env.local` and set `DATABASE_URL` and `BASE_URL`.

2. Create `links` table in your Postgres DB:
```sql
CREATE TABLE links (
  code varchar(8) PRIMARY KEY,
  target_url text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  clicks bigint NOT NULL DEFAULT 0,
  last_clicked timestamptz NULL
);
```

3. Install & run:
```bash
npm install
npm run dev
# open http://localhost:3000
```

## Environment variables
See `.env.example`. At minimum set:
- `DATABASE_URL` — Postgres connection string
- `BASE_URL` — e.g. http://localhost:3000 or your Vercel URL

## API Endpoints (required for autograder)
- `POST /api/links` — Create link (409 if code exists)
- `GET /api/links` — List links
- `GET /api/links/:code` — Link details
- `DELETE /api/links/:code` — Delete
- `GET /healthz` — Health check
