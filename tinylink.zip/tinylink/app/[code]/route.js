import db from "../../lib/db"

export async function GET(request, { params }){
  const { code } = params
  try{
    const link = await db.getLinkByCode(code)
    if(!link) return new Response('Not found', { status: 404 })

    await db.incrementClick(code)
    return Response.redirect(link.target_url, 302)
  }catch(err){
    console.error(err)
    return new Response('Server error', { status: 500 })
  }
}
