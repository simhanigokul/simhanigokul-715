export const metadata = {
  title: 'TinyLink',
  description: 'Simple URL shortener'
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head />
      <body>
        <div style={{fontFamily: 'Arial, sans-serif', maxWidth: 960, margin: '0 auto', padding: 20}}>
          <header style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20}}>
            <h1>TinyLink</h1>
            <div style={{fontSize:12,color:'#666'}}>Mini URL shortener</div>
          </header>
          <main>{children}</main>
          <footer style={{marginTop:40,fontSize:12,color:'#666'}}>Built for TinyLink assignment</footer>
        </div>
      </body>
    </html>
  )
}
