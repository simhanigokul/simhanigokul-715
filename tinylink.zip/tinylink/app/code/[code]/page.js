import React from "react"

async function getLink(code){
  const res = await fetch(`${process.env.BASE_URL}/api/links/${code}`)
  if(res.status === 200) return res.json()
  return null
}

export default async function Page({ params }){
  const { code } = params
  const link = await getLink(code)
  if(!link) return <div>Not found</div>

  return (
    <div>
      <h2>Stats for {code}</h2>
      <p><strong>Target:</strong> <a href={link.target_url} target="_blank" rel="noreferrer">{link.target_url}</a></p>
      <p><strong>Clicks:</strong> {link.clicks}</p>
      <p><strong>Last clicked:</strong> {link.last_clicked ? new Date(link.last_clicked).toLocaleString() : '-'}</p>
      <p><strong>Created at:</strong> {new Date(link.created_at).toLocaleString()}</p>
    </div>
  )
}
