"use client"
import { useEffect, useState } from "react"

function validateUrl(value){
  try{
    const u = new URL(value); return u.protocol === "http:" || u.protocol === "https:"
  }catch(e){return false}
}

export default function Dashboard(){
  const [links,setLinks] = useState([])
  const [loading,setLoading] = useState(false)
  const [targetUrl,setTargetUrl] = useState('')
  const [code,setCode] = useState('')
  const [error,setError] = useState('')

  const fetchLinks = async ()=>{
    setLoading(true)
    const res = await fetch('/api/links')
    const data = await res.json()
    setLinks(data)
    setLoading(false)
  }

  useEffect(()=>{ fetchLinks() }, [])

  const handleCreate = async (e)=>{
    e.preventDefault(); setError('')
    if(!validateUrl(targetUrl)) return setError('Enter a valid http/https URL')
    setLoading(true)
    const res = await fetch('/api/links', { method:'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ target_url: targetUrl, code: code || undefined }) })
    if(res.status === 201){
      setTargetUrl(''); setCode(''); await fetchLinks()
    } else if(res.status === 409){
      setError('Code already exists')
    } else {
      const txt = await res.text(); setError(txt || 'Create failed')
    }
    setLoading(false)
  }

  const handleDelete = async (c)=>{
    if(!confirm('Delete '+c+'?')) return
    await fetch('/api/links/' + c, { method: 'DELETE' })
    await fetchLinks()
  }

  return (
    <div>
      <section style={{marginBottom:20}}>
        <h2>Create short link</h2>
        <form onSubmit={handleCreate}>
          <div style={{display:'flex',gap:8}}>
            <input value={targetUrl} onChange={e=>setTargetUrl(e.target.value)} placeholder="https://example.com" style={{flex:1,padding:8}} />
            <input value={code} onChange={e=>setCode(e.target.value)} placeholder="custom code (6-8 chars)" style={{width:220,padding:8}} />
            <button disabled={loading} style={{padding:'8px 12px'}}>Create</button>
          </div>
          {error && <div style={{color:'red',marginTop:8}}>{error}</div>}
        </form>
      </section>

      <section>
        <h2>Links</h2>
        {loading ? <div>Loading...</div> : (
          <table style={{width:'100%',borderCollapse:'collapse'}}>
            <thead>
              <tr style={{textAlign:'left',borderBottom:'1px solid #ddd'}}>
                <th>Code</th><th>Target URL</th><th>Clicks</th><th>Last Clicked</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {links.map(l=> (
                <tr key={l.code} style={{borderBottom:'1px solid #eee'}}>
                  <td><a href={`/${l.code}`} target="_blank" rel="noreferrer">{l.code}</a></td>
                  <td style={{maxWidth:400,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}} title={l.target_url}>{l.target_url}</td>
                  <td>{l.clicks}</td>
                  <td>{l.last_clicked ? new Date(l.last_clicked).toLocaleString() : '-'}</td>
                  <td><button onClick={()=>handleDelete(l.code)} style={{padding:'4px 8px'}}>Delete</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </div>
  )
}
