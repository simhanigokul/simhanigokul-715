import db from "../../../lib/db"

const CODE_RE = /^[A-Za-z0-9]{6,8}$/

export async function GET(){
  const rows = await db.listLinks()
  return new Response(JSON.stringify(rows), { status: 200, headers: { "Content-Type":"application/json" } })
}

async function generateCode(){
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
  let attempt = 0
  while(attempt < 5){
    const len = 6
    let c = Array.from({length:len}).map(()=>chars[Math.floor(Math.random()*chars.length)]).join("")
    const exists = await db.getLinkByCode(c)
    if(!exists) return c
    attempt++
  }
  return Math.random().toString(36).slice(2,8)
}

export async function POST(request){
  const body = await request.json()
  const target_url = body.target_url
  let code = body.code

  if(!target_url) return new Response("target_url required", { status: 400 })
  try{ new URL(target_url) }catch(e){ return new Response("invalid url", { status: 400 }) }

  if(code){
    if(!CODE_RE.test(code)) return new Response("invalid code format", { status: 400 })
    const exists = await db.getLinkByCode(code)
    if(exists) return new Response(JSON.stringify({ error: "Code already exists"}), { status: 409, headers: { "Content-Type":"application/json" } })
  } else {
    code = await generateCode()
  }

  const created = await db.insertLink(code, target_url)
  return new Response(JSON.stringify(created), { status: 201, headers: { "Content-Type":"application/json" } })
}

export async function DELETE(request){
  const url = new URL(request.url)
  const parts = url.pathname.split("/")
  const code = parts[parts.length-1]
  const exists = await db.getLinkByCode(code)
  if(!exists) return new Response("Not found", { status: 404 })
  await db.deleteLink(code)
  return new Response(null, { status: 204 })
}
